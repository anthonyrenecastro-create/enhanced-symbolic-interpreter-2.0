import random
import copy
import uuid
import math
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from collections import Counter, defaultdict


# ============================================================
# TRACE / CAUSAL DATA STRUCTURES
# ============================================================

@dataclass
class TraceEvent:
    tick: int
    opcode: str
    payload: Any
    channel: Optional[int] = None
    domain: Optional[int] = None
    source: Optional[Tuple[int, int]] = None
    target: Optional[Tuple[int, int]] = None
    cause_state_ids: List[str] = field(default_factory=list)
    cause_memory_keys: List[str] = field(default_factory=list)
    task_score_before: float = 0.0
    task_score_after: float = 0.0
    changed_downstream: bool = False
    influenced_branch: bool = False
    influenced_output: bool = False
    influenced_state: bool = False


@dataclass
class ActiveState:
    id: str
    value: float
    channel: int
    domain: int
    coherence: float = 0.0
    energy: float = 1.0
    age: int = 0
    tags: List[str] = field(default_factory=list)
    influenced_other_state: bool = False
    influenced_output: bool = False
    state_id: str = ""
    parent_state_id: Optional[str] = None
    originating_statement_id: Optional[str] = None
    originating_program_id: Optional[str] = None
    generation: int = 0
    episode: int = 0
    creation_tick: int = 0
    productive: bool = False


@dataclass
class MemoryWriteRecord:
    write_id: str
    tick: int
    key: str
    value: Any


@dataclass
class AttractorEvent:
    attractor_id: str
    signature: str
    tick: int
    entry_states: List[str] = field(default_factory=list)
    exit_states: List[str] = field(default_factory=list)
    duration: int = 1
    associated_outputs: int = 0
    task_contribution: float = 0.0
    causal_contribution: float = 0.0


@dataclass
class MemoryReadRecord:
    tick: int
    key: str
    value: Any
    consumed_by_branch: bool = False
    consumed_by_output: bool = False
    consumed_by_emit: bool = False
    consumed_by_field: bool = False
    consumed_by_couple: bool = False
    changed_downstream: bool = False
    write_id: Optional[str] = None
    exists: bool = False
    task_contribution: float = 0.0


@dataclass
class CoordinationTask:
    min_distinct_domains_emitted: int = 2
    min_distinct_domains_coupled: int = 2
    require_memory_use: bool = False
    require_output: bool = True
    require_cross_domain_sequence: bool = True
    expected_outputs: Optional[List[str]] = None
    family: str = "coordination"
    input_values: Dict[str, float] = field(default_factory=dict)
    delay_ticks: int = 0
    require_state_productivity: bool = False
    require_attractor_use: bool = False
    require_conditional: bool = False
    require_domain_coupling: bool = False
    target_formula: str = "identity"


@dataclass
class TaskSplits:
    training: List[CoordinationTask]
    validation: List[CoordinationTask]
    held_out: List[CoordinationTask]


def make_task_splits(seed: int = 0, size: int = 6) -> TaskSplits:
    """Create deterministic procedural tasks with family-specific causal requirements."""
    rng = random.Random(seed)
    families = ["memory", "causal", "attractor", "conditional", "delayed", "cross_domain", "negative_control"]
    tasks = []
    for index in range(max(3, size * 3)):
        value = float(rng.randrange(-9, 10))
        distractor = float(rng.randrange(-9, 10))
        while distractor == value:
            distractor = float(rng.randrange(-9, 10))
        family = families[index % len(families)]
        if family in {"memory", "delayed"} and distractor == 0.0:
            distractor = 1.0
        if family in {"memory", "delayed"}:
            target = value + distractor
        elif family in {"causal", "cross_domain"}:
            target = value * 2.0 - distractor
        elif family == "conditional":
            target = value + distractor if value >= 0 else value - distractor
        elif family == "attractor":
            target = round((value + distractor) / 2.0, 6)
        else:
            target = value - distractor
        tasks.append(CoordinationTask(
            min_distinct_domains_emitted=2 if family in {"causal", "cross_domain", "attractor"} else 0,
            min_distinct_domains_coupled=2 if family in {"causal", "cross_domain"} else 0,
            require_memory_use=family in {"memory", "delayed"},
            require_cross_domain_sequence=family in {"causal", "cross_domain"},
            expected_outputs=[str(round(target, 6))],
            family=family,
            input_values={"x": value, "y": distractor},
            delay_ticks=3 if family == "delayed" else 0,
            require_state_productivity=family in {"causal", "cross_domain"},
            require_attractor_use=family == "attractor",
            require_conditional=family == "conditional",
            require_domain_coupling=family in {"causal", "cross_domain"},
            target_formula=family,
        ))
    return TaskSplits(tasks[:size], tasks[size:size * 2], tasks[size * 2:size * 3])


# ============================================================
# MORPHOFIELD RUNTIME
# ============================================================

@dataclass
class Runtime:
    num_channels: int = 4
    num_domains: int = 6
    task_spec: CoordinationTask = field(default_factory=CoordinationTask)

    fields: Dict[str, List[List[float]]] = field(default_factory=dict)
    active_states: List[ActiveState] = field(default_factory=list)
    retired_states: Dict[str, ActiveState] = field(default_factory=dict)

    memory_bank: Dict[str, Any] = field(default_factory=dict)
    memory_writes: List[Tuple[int, str, Any]] = field(default_factory=list)
    memory_write_records: List[MemoryWriteRecord] = field(default_factory=list)
    memory_reads: List[MemoryReadRecord] = field(default_factory=list)

    attractor_table: Dict[Tuple[int, int], Dict[str, int]] = field(default_factory=dict)
    attractor_events: List[AttractorEvent] = field(default_factory=list)
    output_buffer: List[str] = field(default_factory=list)

    interactions: int = 0
    transitions: int = 0
    steps: int = 0
    failures: int = 0
    task_score: float = 0.0

    trace: List[TraceEvent] = field(default_factory=list)
    emitted_effects: List[Tuple[int, float, int, int]] = field(default_factory=list)
    coupling_effects: List[Tuple[int, int]] = field(default_factory=list)
    field_updates: List[Tuple[int, str, int, int, float]] = field(default_factory=list)

    # causal provenance
    state_effects: Dict[str, List[str]] = field(default_factory=lambda: defaultdict(list))
    current_state_causes: List[str] = field(default_factory=list)
    current_memory_causes: List[str] = field(default_factory=list)
    current_attractor_causes: List[str] = field(default_factory=list)
    last_memory_event_by_key: Dict[str, int] = field(default_factory=dict)
    last_state_event_by_id: Dict[str, int] = field(default_factory=dict)

    # performance
    task_score_history: List[Tuple[int, float]] = field(default_factory=list)
    episode: int = 0
    program_id: Optional[str] = None
    disabled_components: set = field(default_factory=set)

    def __post_init__(self):
        if not self.fields:
            self.fields = {
                "excitability": [[0.5 for _ in range(self.num_domains)] for _ in range(self.num_channels)],
                "persistence": [[0.2 for _ in range(self.num_domains)] for _ in range(self.num_channels)],
                "global_phi": [[0.0 for _ in range(self.num_domains)] for _ in range(self.num_channels)],
                "coherence": [[0.0 for _ in range(self.num_domains)] for _ in range(self.num_channels)],
            }
        self.task_score_history.append((self.steps, self.task_score))

    def clamp_coords(self, channel: int, domain: int) -> Tuple[int, int]:
        return channel % self.num_channels, domain % self.num_domains

    def set_current_state_causes(self, state_ids: List[str]):
        self.current_state_causes = list(dict.fromkeys(state_ids))

    def set_current_memory_causes(self, keys: List[str]):
        self.current_memory_causes = list(dict.fromkeys(keys))

    def clear_current_causes(self):
        self.current_state_causes = []
        self.current_memory_causes = []
        self.current_attractor_causes = []

    def distinct_emitted_domains(self) -> set:
        return {dm for _, _, _, dm in self.emitted_effects}

    def distinct_coupled_domains(self) -> set:
        ds = set()
        for s, t in self.coupling_effects:
            ds.add(s)
            ds.add(t)
        return ds

    def has_cross_domain_sequence(self) -> bool:
        last_domain = None
        for ev in self.trace:
            if ev.opcode in {"EMIT", "STATE_EMIT"} and ev.domain is not None:
                if last_domain is not None and ev.domain != last_domain:
                    return True
                last_domain = ev.domain
            elif ev.opcode in {"COUPLE", "STATE_COUPLE"} and isinstance(ev.payload, dict):
                src = ev.payload.get("src_domain")
                dst = ev.payload.get("dst_domain")
                if src is not None and dst is not None and src != dst:
                    return True
        return False

    def has_true_interdomain_dependency(self) -> bool:
        touched_pairs = set()
        for ev in self.trace:
            if ev.opcode in {"COUPLE", "STATE_COUPLE"} and isinstance(ev.payload, dict):
                src = ev.payload.get("src_domain")
                dst = ev.payload.get("dst_domain")
                if src is not None and dst is not None and src != dst:
                    touched_pairs.add((src, dst))
            if ev.opcode in {"STATE_EMIT"} and ev.source and ev.target:
                src_domain = ev.source[1]
                tgt_domain = ev.target[1]
                if src_domain is not None and tgt_domain is not None and src_domain != tgt_domain:
                    touched_pairs.add((src_domain, tgt_domain))
        return len(touched_pairs) > 0

    def has_useful_memory(self) -> bool:
        for rec in self.memory_reads:
            if rec.exists and rec.write_id and rec.changed_downstream and rec.task_contribution > 0:
                return True
        return False

    def task_accuracy(self) -> float:
        if not self.task_spec.expected_outputs:
            return self.task_score
        expected = {str(v) for v in self.task_spec.expected_outputs}
        if not any(value in expected for value in self.output_buffer):
            return 0.0
        if self.task_spec.require_memory_use and not any(
            rec.exists and rec.write_id and rec.changed_downstream for rec in self.memory_reads
        ):
            return 0.0
        if self.task_spec.require_state_productivity and not any(
            state.influenced_output for state in self.all_states()
        ):
            return 0.0
        if self.task_spec.require_attractor_use and not any(
            event.associated_outputs > 0 for event in self.attractor_events
        ):
            return 0.0
        if self.task_spec.require_conditional and not any(event.opcode == "IF" for event in self.trace):
            return 0.0
        if self.task_spec.require_domain_coupling and not self.has_true_interdomain_dependency():
            return 0.0
        if self.task_spec.delay_ticks and self.steps < self.task_spec.delay_ticks:
            return 0.0
        return 1.0

    def all_states(self) -> List[ActiveState]:
        return list(self.retired_states.values()) + list(self.active_states)

    def count_useful_states(self) -> int:
        useful_state_count = 0
        for st in self.all_states():
            if st.influenced_other_state and st.influenced_output:
                useful_state_count += 1
        return useful_state_count

    def recompute_task_score(self):
        repeated_attractors = 0
        for _, bucket in self.attractor_table.items():
            for _, count in bucket.items():
                if count >= 2:
                    repeated_attractors += 1

        inter_domain_ok = self.has_true_interdomain_dependency()
        memory_ok = self.has_useful_memory()
        state_ok = self.count_useful_states() > 0
        output_ok = len(self.output_buffer) > 0
        attractor_ok = repeated_attractors > 0

        if not inter_domain_ok:
            self.task_score = 0.0
            self.task_score_history.append((self.steps, self.task_score))
            return

        score = 0.0
        if output_ok:
            score += 0.15
        if attractor_ok:
            score += 0.10
        if memory_ok:
            score += 0.25
        if state_ok:
            score += 0.25
        if len(self.distinct_emitted_domains()) >= self.task_spec.min_distinct_domains_emitted:
            score += 0.15
        if len(self.distinct_coupled_domains()) >= self.task_spec.min_distinct_domains_coupled:
            score += 0.10

        self.task_score = min(1.0, score)
        self.task_score_history.append((self.steps, self.task_score))

    def mark_trace_event_downstream(self, idx: int, *, branch=False, output=False, state=False):
        if 0 <= idx < len(self.trace):
            self.trace[idx].changed_downstream = True
            if branch:
                self.trace[idx].influenced_branch = True
            if output:
                self.trace[idx].influenced_output = True
            if state:
                self.trace[idx].influenced_state = True

    def log(self, opcode: str, payload: Any, channel=None, domain=None, source=None, target=None):
        before = self.task_score
        self.recompute_task_score()
        after = self.task_score
        self.trace.append(
            TraceEvent(
                tick=self.steps,
                opcode=opcode,
                payload=payload,
                channel=channel,
                domain=domain,
                source=source,
                target=target,
                cause_state_ids=list(self.current_state_causes),
                cause_memory_keys=list(self.current_memory_causes),
                task_score_before=before,
                task_score_after=after,
            )
        )
        event_idx = len(self.trace) - 1

        for sid in self.current_state_causes:
            self.state_effects[sid].append(opcode)
            self.last_state_event_by_id[sid] = event_idx

        for k in self.current_memory_causes:
            self.last_memory_event_by_key[k] = event_idx

    def emit_state(self, value: float, channel: int, domain: int, tag: Optional[str] = None):
        if "state" in self.disabled_components:
            return ActiveState(id=str(uuid.uuid4()), value=float(value), channel=channel, domain=domain)
        channel, domain = self.clamp_coords(channel, domain)
        state_id = str(uuid.uuid4())
        parent_id = self.current_state_causes[-1] if self.current_state_causes else None
        st = ActiveState(
            id=state_id,
            value=float(value),
            channel=channel,
            domain=domain,
            coherence=self.fields["coherence"][channel][domain],
            energy=1.0 + self.fields["persistence"][channel][domain],
            age=0,
            tags=[tag] if tag else [],
            state_id=state_id,
            parent_state_id=parent_id,
            originating_program_id=self.program_id,
            generation=(self._state_generation(parent_id) + 1 if parent_id else 0),
            episode=self.episode,
            creation_tick=self.steps,
        )
        self.active_states.append(st)
        self.transitions += 1
        self.emitted_effects.append((self.steps, round(float(value), 6), channel, domain))
        self.log("EMIT", round(float(value), 6), channel=channel, domain=domain, target=(channel, domain))
        return st

    def record_attractor(self, channel: int, domain: int, label: str):
        if "attractor" in self.disabled_components:
            return
        key = (channel, domain)
        if key not in self.attractor_table:
            self.attractor_table[key] = {}
        self.attractor_table[key][label] = self.attractor_table[key].get(label, 0) + 1
        self.attractor_events.append(
            AttractorEvent(
                attractor_id=str(uuid.uuid4()),
                signature=f"c{channel}d{domain}:{label}",
                tick=self.steps,
                entry_states=list(self.current_state_causes),
            )
        )

    def update_memory(self, key: str, value: Any):
        write_id = str(uuid.uuid4())
        self.memory_bank[key] = value
        self.memory_writes.append((self.steps, key, value))
        self.memory_write_records.append(MemoryWriteRecord(write_id, self.steps, key, value))
        self.log("UPDATE_MEMORY", {"key": key, "value": value, "write_id": write_id})

    def read_memory(self, key: str) -> Any:
        if "memory" in self.disabled_components:
            self.memory_reads.append(MemoryReadRecord(tick=self.steps, key=key, value=None))
            return None
        val = self.memory_bank.get(key, None)
        write = next((w for w in reversed(self.memory_write_records) if w.key == key), None)
        self.memory_reads.append(MemoryReadRecord(
            tick=self.steps, key=key, value=val, write_id=write.write_id if write else None,
            exists=write is not None and val == write.value,
        ))
        if write is not None:
            self.current_memory_causes.append(key)
        self.log("READ_MEMORY", {"key": key, "value": val})
        return val

    def mark_memory_use(self, key: str, use_type: str):
        for rec in reversed(self.memory_reads):
            if rec.key == key:
                if use_type == "branch":
                    rec.consumed_by_branch = True
                elif use_type == "output":
                    rec.consumed_by_output = True
                elif use_type == "emit":
                    rec.consumed_by_emit = True
                elif use_type == "field":
                    rec.consumed_by_field = True
                elif use_type == "couple":
                    rec.consumed_by_couple = True

                if rec.exists and use_type in {"branch", "output"}:
                    rec.changed_downstream = True

                idx = self.last_memory_event_by_key.get(key)
                if idx is not None:
                    self.mark_trace_event_downstream(
                        idx,
                        branch=(use_type == "branch"),
                        output=(use_type == "output"),
                        state=False
                    )
                break

    def mark_successful_output(self):
        if self.task_accuracy() <= 0.0:
            return
        for rec in reversed(self.memory_reads):
            if rec.exists and rec.changed_downstream:
                rec.task_contribution = 1.0
                break
        for event in reversed(self.attractor_events):
            if event.associated_outputs or event.causal_contribution:
                event.task_contribution = 1.0
                break
        for sid in self.current_state_causes:
            current = sid
            while current:
                self.mark_state_influenced_output(current)
                parent = None
                for state in self.all_states():
                    if state.id == current:
                        state.productive = True
                        parent = state.parent_state_id
                        break
                current = parent

    def _state_generation(self, parent_id: Optional[str]) -> int:
        if not parent_id:
            return 0
        for state in self.all_states():
            if state.id == parent_id:
                return state.generation
        return 0

    def mark_attractor_use(self, signature: str, output: bool = False):
        for event in reversed(self.attractor_events):
            if event.signature == signature:
                event.causal_contribution += 1.0
                if output:
                    event.associated_outputs += 1
                return

    def mark_state_influenced_other_state(self, state_id: str):
        for st in self.all_states():
            if st.id == state_id:
                st.influenced_other_state = True
                idx = self.last_state_event_by_id.get(state_id)
                if idx is not None:
                    self.mark_trace_event_downstream(idx, state=True)
                break

    def mark_state_influenced_output(self, state_id: str):
        for st in self.all_states():
            if st.id == state_id:
                st.influenced_output = True
                idx = self.last_state_event_by_id.get(state_id)
                if idx is not None:
                    self.mark_trace_event_downstream(idx, output=True)
                break

    def read_attractor(self, channel: int, domain: int) -> Optional[str]:
        key = self.clamp_coords(channel, domain)
        if key not in self.attractor_table or not self.attractor_table[key]:
            self.log("READ_ATTRACTOR", {"coord": key, "value": None}, channel=key[0], domain=key[1])
            return None
        best = max(self.attractor_table[key].items(), key=lambda kv: kv[1])[0]
        self.log("READ_ATTRACTOR", {"coord": key, "value": best}, channel=key[0], domain=key[1])
        return best

    def retire_state(self, st: ActiveState):
        self.retired_states[st.id] = copy.deepcopy(st)

    def tick_states(self):
        new_states = []
        produced_effects = 0

        for st in self.active_states:
            st.age += 1
            ex = self.fields["excitability"][st.channel][st.domain]
            pe = self.fields["persistence"][st.channel][st.domain]
            co = self.fields["coherence"][st.channel][st.domain]
            gp = self.fields["global_phi"][st.channel][st.domain]

            st.energy = st.energy * (0.82 + 0.12 * pe)
            st.coherence = 0.65 * st.coherence + 0.35 * co
            st.value = st.value * (0.88 + 0.08 * ex)

            label = f"{round(st.value, 2)}|c{st.channel}d{st.domain}"
            self.record_attractor(st.channel, st.domain, label)

            self.set_current_state_causes([st.id])

            # 1. High-energy states reinforce local coherence
            if st.energy > 0.6:
                self.fields["coherence"][st.channel][st.domain] = min(
                    1.0,
                    self.fields["coherence"][st.channel][st.domain] + 0.05
                )
                self.field_updates.append(
                    (self.steps, "coherence", st.channel, st.domain, self.fields["coherence"][st.channel][st.domain])
                )
                self.log(
                    "STATE_FIELD_UPDATE",
                    {"state": st.id, "field": "coherence", "delta": 0.05},
                    channel=st.channel,
                    domain=st.domain
                )
                produced_effects += 1

            # 2. Coherent states emit descendants into neighboring domains
            if st.coherence > 0.45 and st.energy > 0.4:
                target_domain = (st.domain + 1) % self.num_domains
                child_value = st.value * 0.5
                child = self.emit_state(child_value, st.channel, target_domain, tag="state_child")
                self.log(
                    "STATE_EMIT",
                    {"state": st.id, "child_value": round(child_value, 6)},
                    channel=st.channel,
                    domain=target_domain,
                    source=(st.channel, st.domain),
                    target=(st.channel, target_domain)
                )
                self.mark_state_influenced_other_state(st.id)
                # child inherits causal relation indirectly by being created
                produced_effects += 1

            # 3. Strong states trigger cross-domain coupling
            if st.energy > 0.75 and gp > 0.2:
                target_domain = (st.domain + 2) % self.num_domains
                if target_domain != st.domain:
                    self.couple(st.domain, target_domain)
                    self.log(
                        "STATE_COUPLE",
                        {"state": st.id, "src_domain": st.domain, "dst_domain": target_domain},
                        channel=st.channel,
                        domain=st.domain,
                        source=(st.channel, st.domain),
                        target=(st.channel, target_domain)
                    )
                    produced_effects += 1

            # 4. Persistent states write memory
            if st.age >= 2 and st.coherence > 0.35:
                mem_key = f"state_{st.channel}_{st.domain}"
                mem_val = round(st.value, 4)
                self.update_memory(mem_key, mem_val)
                self.log(
                    "STATE_MEMORY_WRITE",
                    {"state": st.id, "key": mem_key, "value": mem_val},
                    channel=st.channel,
                    domain=st.domain
                )
                produced_effects += 1

            self.clear_current_causes()

            if st.energy > 0.14 and st.age < 12:
                new_states.append(st)
            else:
                self.retire_state(st)

        self.active_states = new_states
        self.steps += 1
        self.log("TICK", {"tick": self.steps, "state_effects": produced_effects})

    def couple(self, src_domain: int, dst_domain: int):
        if "coupling" in self.disabled_components:
            return
        src_domain %= self.num_domains
        dst_domain %= self.num_domains
        self.interactions += 1
        self.coupling_effects.append((src_domain, dst_domain))
        self.log("COUPLE", {"src_domain": src_domain, "dst_domain": dst_domain}, source=(None, src_domain), target=(None, dst_domain))

        for ch in range(self.num_channels):
            src_coh = self.fields["coherence"][ch][src_domain]
            self.fields["coherence"][ch][dst_domain] = min(
                1.0, 0.8 * self.fields["coherence"][ch][dst_domain] + 0.2 * src_coh + 0.05
            )
            self.fields["global_phi"][ch][dst_domain] = min(
                1.0, 0.9 * self.fields["global_phi"][ch][dst_domain] + 0.1 * self.fields["global_phi"][ch][src_domain] + 0.03
            )

    def spawn_channel(self, from_channel: int):
        from_channel %= self.num_channels
        new_channel = (from_channel + 1) % self.num_channels
        self.log("SPAWN_CHANNEL", {"from": from_channel, "to": new_channel}, source=(from_channel, None), target=(new_channel, None))
        for d in range(self.num_domains):
            self.fields["excitability"][new_channel][d] = 0.5 * self.fields["excitability"][new_channel][d] + 0.5 * self.fields["excitability"][from_channel][d]
            self.fields["persistence"][new_channel][d] = 0.5 * self.fields["persistence"][new_channel][d] + 0.5 * self.fields["persistence"][from_channel][d]
        self.transitions += 1
        return new_channel


# ============================================================
# SYMBOLIC LANGUAGE: LIMITS & VOCABULARY
# ============================================================

NUM_CHANNELS = 4
NUM_DOMAINS = 6
VAR_NAMES = ["x", "y", "z", "w", "a", "b"]
FIELD_NAMES = ["excitability", "persistence", "global_phi", "coherence"]
MEMORY_KEYS = ["k1", "k2", "k3", "k4"] + [
    f"state_{c}_{d}" for c in range(NUM_CHANNELS) for d in range(NUM_DOMAINS)
]

MAX_PROGRAM_LEN = 40        # max top-level statements in a program
MAX_AST_DEPTH = 4           # max expression nesting depth
MAX_BRANCH_DEPTH = 2        # max nested if/else depth
MAX_TICK_COUNT = 5          # max ticks a single TickStmt may perform
MAX_CONST_VALUE = 1e6       # numeric safety clamp for constants/results


def _safe_float(value: Any) -> float:
    """Coerce a value to a finite float, defaulting to 0.0 on anything unsafe."""
    if isinstance(value, bool):
        return 1.0 if value else 0.0
    if not isinstance(value, (int, float)):
        return 0.0
    v = float(value)
    if math.isnan(v) or math.isinf(v):
        return 0.0
    return max(-MAX_CONST_VALUE, min(MAX_CONST_VALUE, v))


# ============================================================
# SYMBOLIC LANGUAGE: EXPRESSIONS
# ============================================================

class Expr:
    """Base class for all expression AST nodes."""

    def evaluate(self, rt: "Runtime", env: Dict[str, Any]) -> Any:
        raise NotImplementedError

    def clone(self) -> "Expr":
        raise NotImplementedError


class ConstExpr(Expr):
    """A literal scalar constant, clamped to a safe finite numeric range."""

    def __init__(self, value: float):
        self.value = _safe_float(value)

    def evaluate(self, rt: "Runtime", env: Dict[str, Any]) -> float:
        return self.value

    def clone(self) -> "ConstExpr":
        return ConstExpr(self.value)


class VarExpr(Expr):
    """Reads a variable from the current program environment; undefined names resolve to 0.0."""

    def __init__(self, name: str):
        self.name = name

    def evaluate(self, rt: "Runtime", env: Dict[str, Any]) -> float:
        return _safe_float(env.get(self.name, 0.0))

    def clone(self) -> "VarExpr":
        return VarExpr(self.name)


class BinExpr(Expr):
    """Arithmetic combination of two sub-expressions."""

    OPS = {
        "+": lambda a, b: a + b,
        "-": lambda a, b: a - b,
        "*": lambda a, b: a * b,
    }

    def __init__(self, op: str, left: Expr, right: Expr):
        if op not in BinExpr.OPS:
            raise ValueError(f"invalid binary operator: {op}")
        self.op = op
        self.left = left
        self.right = right

    def evaluate(self, rt: "Runtime", env: Dict[str, Any]) -> float:
        l = self.left.evaluate(rt, env)
        r = self.right.evaluate(rt, env)
        return _safe_float(BinExpr.OPS[self.op](l, r))

    def clone(self) -> "BinExpr":
        return BinExpr(self.op, self.left.clone(), self.right.clone())


class CompareExpr(Expr):
    """A deterministic comparison between two sub-expressions, used for branch conditions."""

    OPS = {
        ">": lambda a, b: a > b,
        "<": lambda a, b: a < b,
        ">=": lambda a, b: a >= b,
        "<=": lambda a, b: a <= b,
        "==": lambda a, b: abs(a - b) < 1e-9,
    }

    def __init__(self, op: str, left: Expr, right: Expr):
        if op not in CompareExpr.OPS:
            raise ValueError(f"invalid comparison operator: {op}")
        self.op = op
        self.left = left
        self.right = right

    def evaluate(self, rt: "Runtime", env: Dict[str, Any]) -> bool:
        l = self.left.evaluate(rt, env)
        r = self.right.evaluate(rt, env)
        return bool(CompareExpr.OPS[self.op](l, r))

    def clone(self) -> "CompareExpr":
        return CompareExpr(self.op, self.left.clone(), self.right.clone())


class MemoryReadExpr(Expr):
    """Reads a value from the runtime memory bank via the real provenance-tracked API."""

    def __init__(self, key: str):
        self.key = key

    def evaluate(self, rt: "Runtime", env: Dict[str, Any]) -> float:
        return _safe_float(rt.read_memory(self.key))

    def clone(self) -> "MemoryReadExpr":
        return MemoryReadExpr(self.key)


class FieldReadExpr(Expr):
    """Reads a scalar from one of the runtime's dynamical fields."""

    def __init__(self, field: str, channel: int, domain: int):
        self.field = field
        self.channel = channel
        self.domain = domain

    def evaluate(self, rt: "Runtime", env: Dict[str, Any]) -> float:
        if self.field not in rt.fields:
            return 0.0
        c, d = rt.clamp_coords(self.channel, self.domain)
        return _safe_float(rt.fields[self.field][c][d])

    def clone(self) -> "FieldReadExpr":
        return FieldReadExpr(self.field, self.channel, self.domain)


class AttractorReadExpr(Expr):
    """Reads the dominant attractor label at a coordinate and converts it to a numeric feature."""

    def __init__(self, channel: int, domain: int):
        self.channel = channel
        self.domain = domain

    def evaluate(self, rt: "Runtime", env: Dict[str, Any]) -> float:
        label = rt.read_attractor(self.channel, self.domain)
        if not label:
            return 0.0
        try:
            signature = f"c{self.channel % rt.num_channels}d{self.domain % rt.num_domains}:{label}"
            rt.current_attractor_causes.append(signature)
            return _safe_float(label.split("|")[0])
        except (ValueError, IndexError):
            return 0.0

    def clone(self) -> "AttractorReadExpr":
        return AttractorReadExpr(self.channel, self.domain)


class StateValueExpr(Expr):
    """Reads the average value of currently active dynamical states."""

    def evaluate(self, rt: "Runtime", env: Dict[str, Any]) -> float:
        states = rt.active_states
        if not states:
            return 0.0
        rt.set_current_state_causes([st.id for st in states])
        return _safe_float(sum(st.value for st in states) / len(states))

    def clone(self) -> "StateValueExpr":
        return StateValueExpr()


def _walk_expr(expr: Expr):
    """Yield an expression node and all of its sub-expressions."""
    yield expr
    if isinstance(expr, (BinExpr, CompareExpr)):
        yield from _walk_expr(expr.left)
        yield from _walk_expr(expr.right)


# ============================================================
# SYMBOLIC LANGUAGE: STATEMENTS
# ============================================================

class Stmt:
    """Base class for all statement AST nodes."""

    def execute(self, rt: "Runtime", env: Dict[str, Any]) -> None:
        raise NotImplementedError

    def clone(self) -> "Stmt":
        raise NotImplementedError


class Block:
    """An ordered sequence of statements, used as a program body or an if/else branch."""

    def __init__(self, statements: Optional[List[Stmt]] = None):
        self.statements = statements if statements is not None else []

    def execute(self, rt: "Runtime", env: Dict[str, Any]) -> None:
        for stmt in self.statements:
            stmt.execute(rt, env)

    def clone(self) -> "Block":
        return Block([s.clone() for s in self.statements])


class AssignStmt(Stmt):
    """Evaluates an expression and assigns the result to a variable in the environment."""

    def __init__(self, target: str, expr: Expr):
        self.target = target
        self.expr = expr

    def execute(self, rt: "Runtime", env: Dict[str, Any]) -> None:
        value = _safe_float(self.expr.evaluate(rt, env))
        env[self.target] = value
        for e in _walk_expr(self.expr):
            if isinstance(e, MemoryReadExpr):
                rt.mark_memory_use(e.key, "field")
        rt.log("ASSIGN", {"target": self.target, "value": value})

    def clone(self) -> "AssignStmt":
        return AssignStmt(self.target, self.expr.clone())


class IfStmt(Stmt):
    """Evaluates a deterministic condition and executes exactly one of two branches."""

    def __init__(self, cond_expr: Expr, then_block: Block, else_block: Block):
        self.cond_expr = cond_expr
        self.then_block = then_block
        self.else_block = else_block

    def execute(self, rt: "Runtime", env: Dict[str, Any]) -> None:
        cond_value = self.cond_expr.evaluate(rt, env)
        taken = bool(cond_value)
        for e in _walk_expr(self.cond_expr):
            if isinstance(e, MemoryReadExpr):
                rt.mark_memory_use(e.key, "branch")
        rt.log("IF", {"cond": cond_value, "branch": "then" if taken else "else"})
        if taken:
            self.then_block.execute(rt, env)
        else:
            self.else_block.execute(rt, env)

    def clone(self) -> "IfStmt":
        return IfStmt(self.cond_expr.clone(), self.then_block.clone(), self.else_block.clone())


class TickStmt(Stmt):
    """Advances the real dynamical-state simulation by a bounded number of ticks."""

    def __init__(self, count_expr: Expr):
        self.count_expr = count_expr

    def execute(self, rt: "Runtime", env: Dict[str, Any]) -> None:
        raw = self.count_expr.evaluate(rt, env)
        n = int(max(0, min(MAX_TICK_COUNT, round(_safe_float(raw)))))
        for _ in range(n):
            rt.tick_states()
        rt.log("TICK_STMT", {"count": n})

    def clone(self) -> "TickStmt":
        return TickStmt(self.count_expr.clone())


class OutputStmt(Stmt):
    """Evaluates an expression and records it as program output, preserving causal traceability."""

    def __init__(self, expr: Expr):
        self.expr = expr

    def execute(self, rt: "Runtime", env: Dict[str, Any]) -> None:
        value = _safe_float(self.expr.evaluate(rt, env))
        rt.output_buffer.append(str(round(value, 6)))
        for e in _walk_expr(self.expr):
            if isinstance(e, MemoryReadExpr):
                rt.mark_memory_use(e.key, "output")
        if isinstance(self.expr, StateValueExpr):
            for st in rt.active_states:
                rt.mark_state_influenced_output(st.id)
        for signature in rt.current_attractor_causes:
            rt.mark_attractor_use(signature, output=True)
        rt.log("OUTPUT", {"value": value})
        rt.mark_successful_output()

    def clone(self) -> "OutputStmt":
        return OutputStmt(self.expr.clone())


class MemWriteStmt(Stmt):
    """Writes an evaluated expression into the runtime memory bank (real provenance-tracked write)."""

    def __init__(self, key: str, expr: Expr):
        self.key = key
        self.expr = expr

    def execute(self, rt: "Runtime", env: Dict[str, Any]) -> None:
        value = _safe_float(self.expr.evaluate(rt, env))
        rt.update_memory(self.key, round(value, 6))

    def clone(self) -> "MemWriteStmt":
        return MemWriteStmt(self.key, self.expr.clone())


class EmitStmt(Stmt):
    """Emits a new active state into the field/domain grid via the real runtime API."""

    def __init__(self, value_expr: Expr, channel: int, domain: int, tag: str = "prog_emit"):
        self.value_expr = value_expr
        self.channel = channel
        self.domain = domain
        self.tag = tag

    def execute(self, rt: "Runtime", env: Dict[str, Any]) -> None:
        value = _safe_float(self.value_expr.evaluate(rt, env))
        rt.emit_state(value, self.channel, self.domain, tag=self.tag)

    def clone(self) -> "EmitStmt":
        return EmitStmt(self.value_expr.clone(), self.channel, self.domain, self.tag)


class CoupleStmt(Stmt):
    """Couples two domains via the real runtime coupling mechanism."""

    def __init__(self, src_domain: int, dst_domain: int):
        self.src_domain = src_domain
        self.dst_domain = dst_domain

    def execute(self, rt: "Runtime", env: Dict[str, Any]) -> None:
        rt.couple(self.src_domain, self.dst_domain)

    def clone(self) -> "CoupleStmt":
        return CoupleStmt(self.src_domain, self.dst_domain)


def _exprs_of_stmt(stmt: Stmt) -> List[Tuple[str, Any]]:
    """Return (attribute_name, owner) pairs for direct expression children of a statement."""
    if isinstance(stmt, AssignStmt):
        return [("expr", stmt)]
    if isinstance(stmt, OutputStmt):
        return [("expr", stmt)]
    if isinstance(stmt, TickStmt):
        return [("count_expr", stmt)]
    if isinstance(stmt, IfStmt):
        return [("cond_expr", stmt)]
    if isinstance(stmt, MemWriteStmt):
        return [("expr", stmt)]
    if isinstance(stmt, EmitStmt):
        return [("value_expr", stmt)]
    return []


def _collect_blocks(block: Block, branch_depth: int = 0, acc: Optional[List[Tuple[Block, int]]] = None):
    """Recursively collect all blocks in a program (including nested if/else branches)."""
    if acc is None:
        acc = []
    acc.append((block, branch_depth))
    for s in block.statements:
        if isinstance(s, IfStmt):
            _collect_blocks(s.then_block, branch_depth + 1, acc)
            _collect_blocks(s.else_block, branch_depth + 1, acc)
    return acc


def _collect_stmts(program: "Program"):
    """Return (block, index, stmt, branch_depth) for every statement in the program."""
    result = []
    for block, bd in _collect_blocks(program.body):
        for i, s in enumerate(block.statements):
            result.append((block, i, s, bd))
    return result


def _find_exprs_of_type(block: Block, expr_type) -> List[Expr]:
    found = []
    for s in block.statements:
        for attr, owner in _exprs_of_stmt(s):
            root = getattr(owner, attr)
            found.extend(e for e in _walk_expr(root) if isinstance(e, expr_type))
        if isinstance(s, IfStmt):
            found.extend(_find_exprs_of_type(s.then_block, expr_type))
            found.extend(_find_exprs_of_type(s.else_block, expr_type))
    return found


# ============================================================
# SYMBOLIC LANGUAGE: VALIDATION
# ============================================================

def validate_expr(expr: Expr, depth: int = 0) -> bool:
    if depth > MAX_AST_DEPTH + 2:
        raise ValueError("expression exceeds maximum nesting depth")
    if isinstance(expr, ConstExpr):
        if not isinstance(expr.value, float) or math.isnan(expr.value) or math.isinf(expr.value):
            raise ValueError("invalid constant value")
    elif isinstance(expr, VarExpr):
        if not isinstance(expr.name, str) or not expr.name:
            raise ValueError("invalid variable name")
    elif isinstance(expr, BinExpr):
        if expr.op not in BinExpr.OPS:
            raise ValueError(f"invalid binary operator: {expr.op}")
        validate_expr(expr.left, depth + 1)
        validate_expr(expr.right, depth + 1)
    elif isinstance(expr, CompareExpr):
        if expr.op not in CompareExpr.OPS:
            raise ValueError(f"invalid comparison operator: {expr.op}")
        validate_expr(expr.left, depth + 1)
        validate_expr(expr.right, depth + 1)
    elif isinstance(expr, MemoryReadExpr):
        if not isinstance(expr.key, str) or not expr.key:
            raise ValueError("invalid memory key")
    elif isinstance(expr, FieldReadExpr):
        if expr.field not in FIELD_NAMES:
            raise ValueError(f"unsupported field: {expr.field}")
    elif isinstance(expr, (AttractorReadExpr, StateValueExpr)):
        pass
    else:
        raise ValueError(f"unsupported expression type: {type(expr).__name__}")
    return True


def validate_stmt(stmt: Stmt, depth: int = 0, branch_depth: int = 0) -> bool:
    if depth > MAX_AST_DEPTH + 2:
        raise ValueError("statement exceeds maximum nesting depth")
    if isinstance(stmt, AssignStmt):
        if stmt.target not in VAR_NAMES:
            raise ValueError(f"invalid assignment target: {stmt.target}")
        validate_expr(stmt.expr)
    elif isinstance(stmt, IfStmt):
        if branch_depth >= MAX_BRANCH_DEPTH:
            raise ValueError("branch nesting exceeds maximum allowed depth")
        validate_expr(stmt.cond_expr)
        validate_block(stmt.then_block, depth + 1, branch_depth + 1)
        validate_block(stmt.else_block, depth + 1, branch_depth + 1)
    elif isinstance(stmt, TickStmt):
        validate_expr(stmt.count_expr)
        if isinstance(stmt.count_expr, ConstExpr):
            if not (0 <= stmt.count_expr.value <= MAX_TICK_COUNT):
                raise ValueError("tick count out of bounds")
    elif isinstance(stmt, OutputStmt):
        validate_expr(stmt.expr)
    elif isinstance(stmt, MemWriteStmt):
        if not isinstance(stmt.key, str) or not stmt.key:
            raise ValueError("invalid memory write key")
        validate_expr(stmt.expr)
    elif isinstance(stmt, EmitStmt):
        validate_expr(stmt.value_expr)
    elif isinstance(stmt, CoupleStmt):
        pass
    else:
        raise ValueError(f"unsupported statement type: {type(stmt).__name__}")
    return True


def validate_block(block: Block, depth: int = 0, branch_depth: int = 0) -> bool:
    if not isinstance(block, Block):
        raise ValueError("expected a Block instance")
    if len(block.statements) > MAX_PROGRAM_LEN:
        raise ValueError("block exceeds maximum statement count")
    for s in block.statements:
        validate_stmt(s, depth, branch_depth)
    return True


def validate_program(program: "Program") -> bool:
    if not isinstance(program, Program):
        raise ValueError("expected a Program instance")
    if not isinstance(program.body, Block):
        raise ValueError("program body must be a Block")
    if len(program.body.statements) == 0:
        raise ValueError("program must contain at least one statement")
    validate_block(program.body, 0, 0)
    if len(flatten_statement_strings(program)) > MAX_PROGRAM_LEN * 4:
        raise ValueError("program exceeds maximum total instruction count")
    return True


# ============================================================
# SYMBOLIC LANGUAGE: RANDOM PROGRAM GENERATION
# ============================================================

def _rand_leaf_expr() -> Expr:
    choice = random.randrange(5)
    if choice == 0:
        return ConstExpr(round(random.uniform(-2.0, 2.0), 4))
    if choice == 1:
        return VarExpr(random.choice(VAR_NAMES))
    if choice == 2:
        return MemoryReadExpr(random.choice(MEMORY_KEYS))
    if choice == 3:
        return FieldReadExpr(
            random.choice(FIELD_NAMES), random.randrange(NUM_CHANNELS), random.randrange(NUM_DOMAINS)
        )
    return StateValueExpr()


def _rand_expr(depth: int) -> Expr:
    if depth <= 0 or random.random() < 0.5:
        return _rand_leaf_expr()
    op = random.choice(list(BinExpr.OPS.keys()))
    return BinExpr(op, _rand_expr(depth - 1), _rand_expr(depth - 1))


def _rand_cond_expr(depth: int) -> Expr:
    op = random.choice(list(CompareExpr.OPS.keys()))
    return CompareExpr(op, _rand_expr(depth), _rand_expr(depth))


def _rand_stmt(depth: int, branch_depth: int, max_branch: int = MAX_BRANCH_DEPTH) -> Stmt:
    options = ["assign", "assign", "tick", "output", "memwrite", "emit", "couple"]
    if branch_depth < max_branch:
        options.append("if")
    choice = random.choice(options)

    if choice == "assign":
        return AssignStmt(random.choice(VAR_NAMES), _rand_expr(max(1, depth)))
    if choice == "tick":
        return TickStmt(ConstExpr(random.randint(0, MAX_TICK_COUNT)))
    if choice == "output":
        return OutputStmt(_rand_expr(max(1, depth)))
    if choice == "memwrite":
        return MemWriteStmt(random.choice(MEMORY_KEYS), _rand_expr(max(1, depth)))
    if choice == "emit":
        return EmitStmt(
            _rand_expr(max(1, depth)), random.randrange(NUM_CHANNELS), random.randrange(NUM_DOMAINS)
        )
    if choice == "couple":
        return CoupleStmt(random.randrange(NUM_DOMAINS), random.randrange(NUM_DOMAINS))

    # if/else, with reduced depth/length to bound total program size
    cond = _rand_cond_expr(max(1, depth - 1))
    then_block = Block([_rand_stmt(max(0, depth - 1), branch_depth + 1, max_branch) for _ in range(random.randint(1, 2))])
    else_block = Block([_rand_stmt(max(0, depth - 1), branch_depth + 1, max_branch) for _ in range(random.randint(1, 2))])
    return IfStmt(cond, then_block, else_block)


def rand_program(program_len: int = 8, max_depth: int = MAX_AST_DEPTH, max_branch_depth: int = MAX_BRANCH_DEPTH) -> "Program":
    """Generate a syntactically valid randomized symbolic program within strict complexity limits."""
    length = max(1, min(int(program_len), MAX_PROGRAM_LEN))
    depth = max(0, min(int(max_depth), MAX_AST_DEPTH))
    branch_limit = max(0, min(int(max_branch_depth), MAX_BRANCH_DEPTH))
    statements = [_rand_stmt(depth, 0, branch_limit) for _ in range(length)]
    program = Program(Block(statements))
    validate_program(program)
    return program


# ============================================================
# SYMBOLIC LANGUAGE: MUTATION
# ============================================================

MUTATION_OPS = [
    "replace_expr", "perturb_const", "replace_var", "insert_stmt",
    "delete_stmt", "swap_stmt", "modify_cond", "modify_tick", "replace_subtree",
]


class _MutationNotApplicable(Exception):
    pass


def _apply_mutation(program: "Program", op: str) -> None:
    stmts_info = _collect_stmts(program)
    if not stmts_info:
        raise _MutationNotApplicable()
    block, idx, stmt, bd = random.choice(stmts_info)

    if op == "replace_expr":
        targets = _exprs_of_stmt(stmt)
        if not targets:
            raise _MutationNotApplicable()
        attr, owner = random.choice(targets)
        if isinstance(owner, IfStmt):
            setattr(owner, attr, _rand_cond_expr(1))
        else:
            setattr(owner, attr, _rand_expr(1))
    elif op == "perturb_const":
        consts = _find_exprs_of_type(program.body, ConstExpr)
        if not consts:
            raise _MutationNotApplicable()
        c = random.choice(consts)
        c.value = _safe_float(c.value + random.uniform(-0.5, 0.5))
    elif op == "replace_var":
        var_exprs = _find_exprs_of_type(program.body, VarExpr)
        if not var_exprs:
            raise _MutationNotApplicable()
        v = random.choice(var_exprs)
        v.name = random.choice(VAR_NAMES)
    elif op == "insert_stmt":
        if len(program.body.statements) >= MAX_PROGRAM_LEN:
            raise _MutationNotApplicable()
        new_stmt = _rand_stmt(1, bd)
        block.statements.insert(random.randint(0, len(block.statements)), new_stmt)
    elif op == "delete_stmt":
        if len(block.statements) <= 1:
            raise _MutationNotApplicable()
        del block.statements[idx]
    elif op == "swap_stmt":
        if len(block.statements) < 2:
            raise _MutationNotApplicable()
        i, j = random.sample(range(len(block.statements)), 2)
        block.statements[i], block.statements[j] = block.statements[j], block.statements[i]
    elif op == "modify_cond":
        if_stmts = [s for _, _, s, _ in stmts_info if isinstance(s, IfStmt)]
        if not if_stmts:
            raise _MutationNotApplicable()
        target = random.choice(if_stmts)
        target.cond_expr = _rand_cond_expr(1)
    elif op == "modify_tick":
        ticks = [s for _, _, s, _ in stmts_info if isinstance(s, TickStmt)]
        if not ticks:
            raise _MutationNotApplicable()
        t = random.choice(ticks)
        t.count_expr = ConstExpr(random.randint(0, MAX_TICK_COUNT))
    elif op == "replace_subtree":
        block.statements[idx] = _rand_stmt(1, bd)
    else:
        raise _MutationNotApplicable()


def mutate_program(program: "Program") -> "Program":
    """Return a mutated deep copy of `program`; the original is never modified."""
    validate_program(program)
    child = clone_program(program)

    op = random.choice(MUTATION_OPS)
    try:
        _apply_mutation(child, op)
    except _MutationNotApplicable:
        pass  # no-op mutation: the (already valid) clone is returned unchanged

    if len(child.body.statements) == 0:
        child.body.statements.append(AssignStmt(random.choice(VAR_NAMES), ConstExpr(0.0)))
    if len(child.body.statements) > MAX_PROGRAM_LEN:
        child.body.statements = child.body.statements[:MAX_PROGRAM_LEN]

    try:
        validate_program(child)
    except ValueError:
        # mutation produced an invalid program: fall back to an untouched clone
        return clone_program(program)

    child.lineage = list(program.lineage) + [program.id]
    return child


# ============================================================
# SYMBOLIC LANGUAGE: CROSSOVER
# ============================================================

def crossover_program(parent_a: "Program", parent_b: "Program") -> "Program":
    """Statement-block crossover of two parents; always returns a valid, independently-owned child."""
    validate_program(parent_a)
    validate_program(parent_b)

    stmts_a = clone_program(parent_a).body.statements
    stmts_b = clone_program(parent_b).body.statements

    if not stmts_a or not stmts_b:
        return clone_program(parent_a)

    cut_a = random.randint(1, len(stmts_a))
    cut_b = random.randint(0, len(stmts_b))
    new_statements = stmts_a[:cut_a] + stmts_b[cut_b:]

    if not new_statements:
        return clone_program(parent_a)
    if len(new_statements) > MAX_PROGRAM_LEN:
        new_statements = new_statements[:MAX_PROGRAM_LEN]

    lineage = list(dict.fromkeys(parent_a.lineage + parent_b.lineage + [parent_a.id, parent_b.id]))
    child = Program(Block(new_statements), lineage=lineage)

    try:
        validate_program(child)
    except ValueError:
        # crossover produced an invalid child (e.g. branch depth violation): fall back gracefully
        return clone_program(parent_a)
    return child


# ============================================================
# SYMBOLIC LANGUAGE: CLONING
# ============================================================

def clone_program(program: "Program") -> "Program":
    """Deep copy a program and all nested AST nodes; no mutable state is shared with the original."""
    return Program(program.body.clone(), id=str(uuid.uuid4()), lineage=list(program.lineage))


# ============================================================
# SYMBOLIC LANGUAGE: REPRESENTATION UTILITIES
# ============================================================

def expr_to_str(expr: Expr) -> str:
    if isinstance(expr, ConstExpr):
        return f"{expr.value:.4g}"
    if isinstance(expr, VarExpr):
        return expr.name
    if isinstance(expr, BinExpr):
        return f"({expr_to_str(expr.left)} {expr.op} {expr_to_str(expr.right)})"
    if isinstance(expr, CompareExpr):
        return f"{expr_to_str(expr.left)} {expr.op} {expr_to_str(expr.right)}"
    if isinstance(expr, MemoryReadExpr):
        return f"mem[{expr.key}]"
    if isinstance(expr, FieldReadExpr):
        return f"field[{expr.field},c{expr.channel},d{expr.domain}]"
    if isinstance(expr, AttractorReadExpr):
        return f"attractor[c{expr.channel},d{expr.domain}]"
    if isinstance(expr, StateValueExpr):
        return "state_value"
    return f"<unknown_expr:{type(expr).__name__}>"


def stmt_to_str(stmt: Stmt) -> str:
    if isinstance(stmt, AssignStmt):
        return f"{stmt.target} = {expr_to_str(stmt.expr)}"
    if isinstance(stmt, TickStmt):
        return f"tick {expr_to_str(stmt.count_expr)}"
    if isinstance(stmt, OutputStmt):
        return f"output {expr_to_str(stmt.expr)}"
    if isinstance(stmt, MemWriteStmt):
        return f"mem[{stmt.key}] = {expr_to_str(stmt.expr)}"
    if isinstance(stmt, EmitStmt):
        return f"emit {expr_to_str(stmt.value_expr)} -> (c{stmt.channel},d{stmt.domain})"
    if isinstance(stmt, CoupleStmt):
        return f"couple d{stmt.src_domain} -> d{stmt.dst_domain}"
    if isinstance(stmt, IfStmt):
        return f"if {expr_to_str(stmt.cond_expr)}:"
    return f"<unknown_stmt:{type(stmt).__name__}>"


def flatten_statement_strings(program: "Program") -> List[str]:
    """Return a flat, order-stable sequence of normalized statement strings, recursing into branches."""
    result: List[str] = []

    def _walk(block: Block):
        for s in block.statements:
            result.append(stmt_to_str(s))
            if isinstance(s, IfStmt):
                _walk(s.then_block)
                _walk(s.else_block)

    _walk(program.body)
    return result


def _block_to_str(block: Block, indent: int = 0) -> List[str]:
    pad = "    " * indent
    lines = []
    for s in block.statements:
        if isinstance(s, IfStmt):
            lines.append(f"{pad}{stmt_to_str(s)}")
            lines.extend(_block_to_str(s.then_block, indent + 1))
            lines.append(f"{pad}else:")
            lines.extend(_block_to_str(s.else_block, indent + 1))
        else:
            lines.append(f"{pad}{stmt_to_str(s)}")
    return lines


def program_to_str(program: "Program") -> str:
    """Render the complete symbolic program as readable, indented source text."""
    return "\n".join(_block_to_str(program.body, 0))


# ============================================================
# PROGRAM
# ============================================================

class Program:
    def __init__(self, body, id=None, lineage=None):
        self.body = body
        self.id = id or str(uuid.uuid4())
        self.lineage = lineage or []

    def run(self, rt: Runtime) -> Dict[str, Any]:
        rt.program_id = self.id
        env = dict(rt.task_spec.input_values)
        try:
            self.body.execute(rt, env)
            success = True
        except Exception as e:
            rt.failures += 1
            env["runtime_error"] = str(e)
            success = False
        return {"success": success, "env": env}


# ============================================================
# FITNESS HELPERS
# ============================================================

def count_instruction_repetition(stmt_strings: List[str]) -> float:
    n = len(stmt_strings)
    if n == 0:
        return 0.0
    counts = Counter(stmt_strings)
    return sum(max(0, c - 1) for c in counts.values()) / n

def count_duplicate_blocks(stmt_strings: List[str], min_block=2, max_block=5) -> float:
    n = len(stmt_strings)
    if n == 0:
        return 0.0
    penalty = 0.0
    for k in range(min_block, min(max_block, n) + 1):
        seen = Counter(tuple(stmt_strings[i:i+k]) for i in range(n - k + 1))
        penalty += sum(max(0, c - 1) * k for c in seen.values())
    return penalty / n

def is_constant_expr(expr) -> bool:
    return isinstance(expr, ConstExpr)

def count_null_ops(program: Program) -> float:
    stmts = program.body.statements
    n = len(stmts)
    if n == 0:
        return 0.0
    nulls = 0
    prev_output = None
    for s in stmts:
        if isinstance(s, AssignStmt) and isinstance(s.expr, VarExpr) and s.target == s.expr.name:
            nulls += 1
        elif isinstance(s, TickStmt) and isinstance(s.count_expr, ConstExpr) and int(s.count_expr.value) == 0:
            nulls += 1
        elif isinstance(s, IfStmt) and is_constant_expr(s.cond_expr):
            nulls += 1
        elif isinstance(s, OutputStmt) and isinstance(s.expr, ConstExpr):
            cur = s.expr.value
            if prev_output == cur:
                nulls += 1
            prev_output = cur
        else:
            prev_output = None
    return nulls / n

def dead_write_penalty(program: Program, rt: Runtime) -> float:
    stmt_strings = flatten_statement_strings(program)
    n = max(1, len(stmt_strings))

    assigned = []
    used = set()
    for s in program.body.statements:
        if isinstance(s, AssignStmt):
            assigned.append(s.target)
        txt = stmt_to_str(s)
        for v in VAR_NAMES:
            if v in txt and not (isinstance(s, AssignStmt) and s.target == v):
                used.add(v)

    unused_bindings = sum(1 for a in assigned if a not in used)

    write_counts = Counter(k for _, k, _ in rt.memory_writes)
    useful_reads = Counter(rec.key for rec in rt.memory_reads if (
        rec.changed_downstream and (rec.consumed_by_branch or rec.consumed_by_output)
    ))
    unused_memory_writes = sum(1 for k in write_counts if useful_reads.get(k, 0) == 0)

    return (unused_bindings + unused_memory_writes) / n

def memory_usefulness_reward(rt: Runtime) -> float:
    valid_reads = [rec for rec in rt.memory_reads if rec.exists and rec.write_id]
    useful_hits = sum(1 for rec in valid_reads if rec.task_contribution > 0)
    return min(1.0, useful_hits / max(1, len(valid_reads)))

def distinct_effect_reward(rt: Runtime) -> float:
    unique_emits = len(set((v, ch, dm) for _, v, ch, dm in rt.emitted_effects))
    unique_couplings = len(set(rt.coupling_effects))
    unique_field_updates = len(set((f, ch, dm) for _, f, ch, dm, _ in rt.field_updates))
    total_effects = len(rt.emitted_effects) + len(rt.coupling_effects) + len(rt.field_updates)
    return (unique_emits + unique_couplings + unique_field_updates) / (1 + total_effects)

def useful_state_reward(rt: Runtime) -> float:
    states = rt.all_states()
    if not states:
        return 0.0
    productive = sum(1 for st in states if st.productive and st.influenced_output)
    return min(1.0, productive / len(states))

def population_robustness_reward(rt: Runtime) -> float:
    domain_counts = Counter()
    age_sum = 0
    survivors = 0

    for st in rt.active_states:
        domain_counts[(st.channel, st.domain)] += 1
        age_sum += st.age
        survivors += 1

    if survivors == 0:
        return 0.0

    spread = len(domain_counts) / max(1, rt.num_channels * rt.num_domains)
    avg_age = age_sum / survivors
    age_score = min(1.0, avg_age / 5.0)

    return 0.6 * spread + 0.4 * age_score

def behavioral_efficiency_reward(core_components: Dict[str, float], instr_count: int) -> float:
    useful = sum(core_components.get(name, 0.0) for name in (
        "task_completion", "memory_usefulness", "state_productivity", "attractor_usefulness"
    ))
    cost = 1.0 + instr_count + core_components.get("execution_cost", 0.0)
    return min(1.0, useful / cost * 4.0)

def length_penalty(instr_count: int, k: int = 12) -> float:
    return instr_count / (instr_count + k) if instr_count > 0 else 0.0

def trace_coherence_reward(rt: Runtime) -> float:
    improving = 0
    total = 0
    for ev in rt.trace:
        if ev.opcode in {
            "EMIT", "COUPLE", "SET_FIELD", "MUTATE_FIELD", "UPDATE_MEMORY",
            "OUTPUT", "READ_MEMORY", "IF", "STATE_FIELD_UPDATE", "STATE_EMIT",
            "STATE_COUPLE", "STATE_MEMORY_WRITE"
        }:
            total += 1
            if ev.changed_downstream and (ev.task_score_after > ev.task_score_before):
                improving += 1
    return improving / max(1, total)


# ============================================================
# FITNESS
# ============================================================

def score_runtime(program: Program, rt: Runtime, run_result: Dict[str, Any]) -> Dict[str, float]:
    stmt_strings = flatten_statement_strings(program)
    instr_count = len(stmt_strings)
    P_instr_rep = count_instruction_repetition(stmt_strings)
    P_block_rep = count_duplicate_blocks(stmt_strings)
    P_null = count_null_ops(program)
    P_dead_write = min(1.0, dead_write_penalty(program, rt))
    P_length = length_penalty(instr_count)
    valid_execution = 1.0 if run_result["success"] else 0.0
    task_completion = min(1.0, max(0.0, rt.task_accuracy()))
    valid_reads = [r for r in rt.memory_reads if r.exists and r.write_id]
    invalid_reads = sum(1 for r in rt.memory_reads if not r.exists)
    R_mem_useful = memory_usefulness_reward(rt)
    R_distinct = distinct_effect_reward(rt)
    R_state_prod = useful_state_reward(rt)
    useful_attractors = sum(1 for e in rt.attractor_events if e.task_contribution > 0)
    R_attractor_useful = min(1.0, useful_attractors / max(1, len(rt.attractor_events)))
    execution_cost = len(rt.trace) + rt.steps + len(rt.memory_reads) + len(rt.memory_writes)
    core = {
        "valid_execution": valid_execution,
        "task_completion": task_completion,
        "execution_cost": float(execution_cost),
        "memory_usefulness": R_mem_useful,
        "state_productivity": R_state_prod,
        "attractor_usefulness": R_attractor_useful,
    }
    R_eff = behavioral_efficiency_reward(core, instr_count)
    R_trace = min(1.0, trace_coherence_reward(rt))
    P_invalid = min(1.0, invalid_reads / max(1, len(rt.memory_reads)))
    states = rt.all_states()
    P_dead = min(1.0, (len(states) - sum(1 for s in states if s.productive)) / max(1, len(states)))
    P_state_explosion = min(1.0, max(0, len(states) - 12) / 12.0)
    P_repeated_output = min(1.0, max(0, len(rt.output_buffer) - 1) / max(1, len(rt.output_buffer)))
    P_ticks = min(1.0, max(0, rt.steps - 8) / 8.0)

    fitness = (
        6.0 * task_completion
        + 1.0 * R_mem_useful * task_completion
        + 1.0 * R_state_prod * task_completion
        + 0.75 * R_attractor_useful * task_completion
        + 0.5 * R_trace * task_completion
        + 0.4 * R_eff
        - 1.5 * P_instr_rep
        - 2.0 * P_block_rep
        - 1.5 * P_null
        - 1.2 * P_dead_write
        - 0.8 * P_length
        - 1.5 * P_invalid
        - 1.0 * P_dead
        - 1.0 * P_state_explosion
        - 1.0 * P_repeated_output
        - 0.5 * P_ticks
    )

    return {
        **core,
        # Legacy diagnostics retained for callers; none contributes directly to fitness.
        "transitions": min(1.0, rt.transitions / 8.0),
        "memory_usage": min(1.0, len(rt.memory_bank) / 8.0),
        "inter_domain": 1.0 if rt.has_true_interdomain_dependency() else 0.0,
        "attractor_stability": min(1.0, sum(1 for e in rt.attractor_events if e.duration > 1) / max(1, len(rt.attractor_events))),
        "R_eff": R_eff,
        "R_distinct": R_distinct,
        "R_mem_useful": R_mem_useful,
        "R_state_prod": R_state_prod,
        "R_pop_robust": 0.0,
        "R_attractor_useful": R_attractor_useful,
        "R_trace": R_trace,
        "P_instr_rep": P_instr_rep,
        "P_block_rep": P_block_rep,
        "P_null": P_null,
        "P_dead_write": P_dead_write,
        "P_length": P_length,
        "P_invalid": P_invalid,
        "P_dead": P_dead,
        "P_state_explosion": P_state_explosion,
        "P_repeated_output": P_repeated_output,
        "P_ticks": P_ticks,
        "valid_memory_writes": len(rt.memory_write_records),
        "valid_memory_reads": len(valid_reads),
        "invalid_memory_reads": invalid_reads,
        "memory_read_write_matches": sum(1 for r in valid_reads if r.write_id),
        "memory_causal_contributions": sum(1 for r in rt.memory_reads if r.task_contribution > 0),
        "memory_task_contributions": sum(r.task_contribution for r in rt.memory_reads),
        "memory_survival_steps": sum(max(0, r.tick - w.tick) for r in rt.memory_reads for w in rt.memory_write_records if r.write_id == w.write_id),
        "productive_states": sum(1 for s in states if s.productive),
        "total_states": len(states),
        "productive_state_fraction": R_state_prod,
        "dead_state_fraction": P_dead,
        "state_lineage_depth": max((s.generation for s in states), default=0),
        "productive_lineage_depth": max((s.generation for s in states if s.productive), default=0),
        "output_caused_by_state_count": sum(1 for s in states if s.influenced_output),
        "successful_state_paths": sum(1 for s in states if s.productive and s.influenced_output),
        "useful_attractor_events": useful_attractors,
        "total_attractor_events": len(rt.attractor_events),
        "causal_trace_quality": R_trace,
        "execution_cost": execution_cost,
        "instr_count": instr_count,
        "fitness": fitness,
        "distinct_emit_domains": len(rt.distinct_emitted_domains()),
        "distinct_coupled_domains": len(rt.distinct_coupled_domains()),
        "useful_state_count": rt.count_useful_states(),
    }


# ============================================================
# EVOLUTION ENGINE
# ============================================================

class ProgramRecord:
    def __init__(self, program, metrics, runtime_snapshot):
        self.program = program
        self.metrics = metrics
        self.runtime_snapshot = runtime_snapshot

class MorphoFieldEvolutionEngine:
    def __init__(self, pop_size=12, program_len=8):
        self.pop_size = pop_size
        self.program_len = program_len
        self.population = [rand_program(program_len) for _ in range(pop_size)]
        self.generation = 0
        self.best_history = []
        self.task_splits = make_task_splits(0)

    def evaluate_program_on_task(self, program: Program, task: CoordinationTask) -> ProgramRecord:
        rt = Runtime(num_channels=NUM_CHANNELS, num_domains=NUM_DOMAINS, task_spec=copy.deepcopy(task))
        result = program.run(rt)
        metrics = score_runtime(program, rt, result)
        return ProgramRecord(program, metrics, rt)

    def evaluate_split(self, program: Program, tasks: List[CoordinationTask]) -> float:
        if not tasks:
            return 0.0
        return sum(self.evaluate_program_on_task(program, task).metrics["task_completion"] for task in tasks) / len(tasks)

    def evaluate_program(self, program: Program) -> ProgramRecord:
        task = self.task_splits.training[self.generation % len(self.task_splits.training)]
        record = self.evaluate_program_on_task(program, task)
        record.metrics["validation_accuracy"] = self.evaluate_split(program, self.task_splits.validation)
        return record

    def select(self, records: List[ProgramRecord]) -> List[ProgramRecord]:
        records = sorted(records, key=lambda r: r.metrics["fitness"], reverse=True)
        return records[:max(2, self.pop_size // 3)]

    def reproduce(self, elites: List[ProgramRecord]) -> List[Program]:
        new_population = []
        for e in elites[:2]:
            new_population.append(clone_program(e.program))
        while len(new_population) < self.pop_size:
            mode = random.choice(["mutate", "crossover", "fresh"])
            if mode == "mutate":
                parent = random.choice(elites).program
                new_population.append(mutate_program(parent))
            elif mode == "crossover" and len(elites) >= 2:
                a = random.choice(elites).program
                b = random.choice(elites).program
                new_population.append(crossover_program(a, b))
            else:
                new_population.append(rand_program(self.program_len))
        return new_population[:self.pop_size]

    def step(self):
        t0 = time.perf_counter()
        records = [self.evaluate_program(p) for p in self.population]
        elites = self.select(records)
        best = elites[0]
        self.best_history.append(best)
        self.population = self.reproduce(elites)
        self.generation += 1
        batch_ms = (time.perf_counter() - t0) * 1000.0
        return best, records, batch_ms

    def held_out_evaluation(self, program: Program) -> float:
        return self.evaluate_split(program, self.task_splits.held_out)


def assert_metric_invariants(metrics: Dict[str, float]) -> None:
    """Fail loudly when a normalized metric escapes its documented semantic range."""
    bounded = [
        "R_mem_useful", "R_state_prod", "R_attractor_useful", "R_trace",
        "P_instr_rep", "P_block_rep", "P_null", "P_dead_write", "P_invalid",
        "P_dead", "P_state_explosion", "P_repeated_output", "P_ticks",
    ]
    for name in bounded:
        if name in metrics and not 0.0 <= metrics[name] <= 1.0:
            raise AssertionError(f"{name} escaped normalized range: {metrics[name]}")
    if metrics.get("R_mem_useful", 0.0) > 0:
        assert metrics.get("valid_memory_reads", 0) > 0
        assert metrics.get("valid_memory_writes", 0) > 0
        assert metrics.get("memory_causal_contributions", 0) > 0
    if metrics.get("R_state_prod", 0.0) > 0:
        assert metrics.get("productive_states", 0) > 0
        assert metrics.get("successful_state_paths", 0) > 0
    if metrics.get("R_attractor_useful", 0.0) > 0:
        assert metrics.get("useful_attractor_events", 0) > 0


def verify_causal_interventions(program: Program, task: CoordinationTask) -> Dict[str, float]:
    """Compare baseline task performance with targeted component ablations."""
    cache = {}

    def run(disabled):
        key = tuple(sorted(disabled))
        if key not in cache:
            rt = Runtime(task_spec=copy.deepcopy(task), disabled_components=set(disabled))
            result = program.run(rt)
            cache[key] = score_runtime(program, rt, result)["task_completion"]
        return cache[key]

    baseline = run(set())
    effects = {"baseline": baseline}
    for component in ("memory", "attractor", "state", "coupling"):
        effects[f"without_{component}"] = max(0.0, baseline - run({component}))
    return effects


def ablation_report(program: Program, task: CoordinationTask) -> Dict[str, Dict[str, float]]:
    """Return causal effects for the architecture components on one task."""
    effects = verify_causal_interventions(program, task)
    return {"task_causal_effects": effects}


# ============================================================
# DEMO / BENCHMARK
# ============================================================

if __name__ == "__main__":
    random.seed(42)
    engine = MorphoFieldEvolutionEngine(pop_size=12, program_len=8)

    for gen in range(10):
        best, records, batch_ms = engine.step()
        valid_rate = sum(r.metrics["valid_execution"] for r in records) / len(records)

        print(f"\n=== Generation {gen} ===")
        print("Batch runtime ms:", round(batch_ms, 3))
        print("Best fitness:", round(best.metrics["fitness"], 4))
        print("Core:", {k: round(best.metrics[k], 4) for k in [
            "valid_execution", "transitions", "memory_usage", "inter_domain",
            "attractor_stability", "task_completion"
        ]})
        print("Coordination:", {
            "distinct_emit_domains": best.metrics["distinct_emit_domains"],
            "distinct_coupled_domains": best.metrics["distinct_coupled_domains"],
            "useful_state_count": best.metrics["useful_state_count"],
        })
        print("Rewards:", {k: round(best.metrics[k], 4) for k in [
            "R_eff", "R_distinct", "R_mem_useful", "R_state_prod", "R_pop_robust", "R_trace"
        ]})
        print("Penalties:", {k: round(best.metrics[k], 4) for k in [
            "P_instr_rep", "P_block_rep", "P_null", "P_dead_write", "P_length"
        ]})
        print("Instr count:", best.metrics["instr_count"])
        print("Valid execution rate:", round(valid_rate, 4))
        print("Program:")
        print(program_to_str(best.program))

    final_best = max(engine.best_history, key=lambda r: r.metrics["fitness"])
    held_out_accuracy = engine.held_out_evaluation(final_best.program)
    assert_metric_invariants(final_best.metrics)
    print("\n=== Final Best Program ===")
    print(program_to_str(final_best.program))
    print("\n=== Benchmark Check ===")
    print("Target: runtime < 10 ms per batch")
    print("Target: valid_execution = 1.0")
    print("Target: P_block_rep = 0")
    print("Target: inter_domain = 1.0")
    print("Target: R_mem_useful > 0.5")
    print("Target: R_state_prod > 0.2")
    print("Train accuracy:", round(final_best.metrics["task_completion"], 4))
    print("Validation accuracy:", round(final_best.metrics["validation_accuracy"], 4))
    print("Held-out accuracy:", round(held_out_accuracy, 4))
    print("Interventions:", ablation_report(final_best.program, engine.task_splits.training[0]))
    print("\nFinal best metrics:")
    print({k: round(final_best.metrics[k], 4) if isinstance(final_best.metrics[k], float) else final_best.metrics[k]
           for k in final_best.metrics})
