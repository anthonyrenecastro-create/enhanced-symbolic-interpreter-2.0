import copy
import random
import unittest

import seer_blue as sb


def fresh_rt():
    return sb.Runtime(num_channels=sb.NUM_CHANNELS, num_domains=sb.NUM_DOMAINS, task_spec=sb.CoordinationTask())


class TestConstExpr(unittest.TestCase):
    def test_literal_value(self):
        rt = fresh_rt()
        self.assertEqual(sb.ConstExpr(0.42).evaluate(rt, {}), 0.42)

    def test_rejects_nan_inf(self):
        self.assertEqual(sb.ConstExpr(float("nan")).value, 0.0)
        self.assertEqual(sb.ConstExpr(float("inf")).value, 0.0)

    def test_clamped_to_safe_range(self):
        self.assertLessEqual(sb.ConstExpr(1e12).value, sb.MAX_CONST_VALUE)


class TestVarExpr(unittest.TestCase):
    def test_reads_assigned_variable(self):
        rt = fresh_rt()
        env = {"x": 3.5}
        self.assertEqual(sb.VarExpr("x").evaluate(rt, env), 3.5)

    def test_undefined_variable_resolves_safely(self):
        rt = fresh_rt()
        self.assertEqual(sb.VarExpr("undefined_var").evaluate(rt, {}), 0.0)


class TestAssignStmt(unittest.TestCase):
    def test_assigns_expression_result(self):
        rt = fresh_rt()
        env = {}
        sb.AssignStmt("x", sb.ConstExpr(1.5)).execute(rt, env)
        self.assertEqual(env["x"], 1.5)

    def test_logs_trace_event(self):
        rt = fresh_rt()
        before = len(rt.trace)
        sb.AssignStmt("x", sb.ConstExpr(2.0)).execute(rt, {})
        self.assertGreater(len(rt.trace), before)


class TestIfStmt(unittest.TestCase):
    def test_executes_then_branch_when_true(self):
        rt = fresh_rt()
        env = {}
        stmt = sb.IfStmt(
            sb.ConstExpr(1.0),
            sb.Block([sb.AssignStmt("x", sb.ConstExpr(1.0))]),
            sb.Block([sb.AssignStmt("x", sb.ConstExpr(-1.0))]),
        )
        stmt.execute(rt, env)
        self.assertEqual(env["x"], 1.0)

    def test_executes_else_branch_when_false(self):
        rt = fresh_rt()
        env = {}
        stmt = sb.IfStmt(
            sb.ConstExpr(0.0),
            sb.Block([sb.AssignStmt("x", sb.ConstExpr(1.0))]),
            sb.Block([sb.AssignStmt("x", sb.ConstExpr(-1.0))]),
        )
        stmt.execute(rt, env)
        self.assertEqual(env["x"], -1.0)

    def test_condition_is_deterministic(self):
        rt1, rt2 = fresh_rt(), fresh_rt()
        cond = sb.CompareExpr(">", sb.ConstExpr(1.0), sb.ConstExpr(0.5))
        self.assertEqual(cond.evaluate(rt1, {}), cond.evaluate(rt2, {}))

    def test_deep_nesting_rejected_by_validation(self):
        innermost = sb.IfStmt(sb.ConstExpr(1.0), sb.Block([sb.AssignStmt("x", sb.ConstExpr(1.0))]), sb.Block([]))
        outer = innermost
        for _ in range(sb.MAX_BRANCH_DEPTH + 2):
            outer = sb.IfStmt(sb.ConstExpr(1.0), sb.Block([outer]), sb.Block([]))
        with self.assertRaises(ValueError):
            sb.validate_stmt(outer, 0, 0)


class TestTickStmt(unittest.TestCase):
    def test_advances_real_state_simulation(self):
        rt = fresh_rt()
        rt.emit_state(1.0, 0, 0, tag="seed")
        steps_before = rt.steps
        sb.TickStmt(sb.ConstExpr(3)).execute(rt, {})
        self.assertEqual(rt.steps, steps_before + 3)

    def test_bounded_tick_count(self):
        rt = fresh_rt()
        steps_before = rt.steps
        sb.TickStmt(sb.ConstExpr(999)).execute(rt, {})
        self.assertEqual(rt.steps, steps_before + sb.MAX_TICK_COUNT)

    def test_negative_ticks_are_safe(self):
        rt = fresh_rt()
        steps_before = rt.steps
        sb.TickStmt(sb.ConstExpr(-5)).execute(rt, {})
        self.assertEqual(rt.steps, steps_before)


class TestOutputStmt(unittest.TestCase):
    def test_records_output(self):
        rt = fresh_rt()
        sb.OutputStmt(sb.ConstExpr(7.0)).execute(rt, {})
        self.assertEqual(rt.output_buffer[-1], str(round(7.0, 6)))

    def test_memory_read_output_is_traceable(self):
        rt = fresh_rt()
        rt.update_memory("k1", 4.0)
        sb.OutputStmt(sb.MemoryReadExpr("k1")).execute(rt, {})
        self.assertTrue(any(rec.consumed_by_output for rec in rt.memory_reads if rec.key == "k1"))


class TestValidation(unittest.TestCase):
    def test_valid_program_passes(self):
        prog = sb.rand_program(6)
        self.assertTrue(sb.validate_program(prog))

    def test_invalid_var_name_rejected(self):
        prog = sb.Program(sb.Block([sb.AssignStmt("not_a_var", sb.ConstExpr(1.0))]))
        with self.assertRaises(ValueError):
            sb.validate_program(prog)

    def test_invalid_tick_count_rejected(self):
        stmt = sb.TickStmt(sb.ConstExpr(999))
        with self.assertRaises(ValueError):
            sb.validate_stmt(stmt)

    def test_unsupported_expr_type_rejected(self):
        class Bogus(sb.Expr):
            def evaluate(self, rt, env):
                return 0.0
            def clone(self):
                return self
        with self.assertRaises(ValueError):
            sb.validate_expr(Bogus())

    def test_unsupported_stmt_type_rejected(self):
        class Bogus(sb.Stmt):
            def execute(self, rt, env):
                pass
            def clone(self):
                return self
        with self.assertRaises(ValueError):
            sb.validate_stmt(Bogus())


class TestRandProgram(unittest.TestCase):
    def test_generates_valid_program(self):
        for _ in range(20):
            prog = sb.rand_program(8)
            sb.validate_program(prog)

    def test_respects_length_limit(self):
        prog = sb.rand_program(500)
        self.assertLessEqual(len(prog.body.statements), sb.MAX_PROGRAM_LEN)

    def test_deterministic_with_seed(self):
        random.seed(123)
        a = sb.program_to_str(sb.rand_program(6))
        random.seed(123)
        b = sb.program_to_str(sb.rand_program(6))
        self.assertEqual(a, b)


class TestMutateProgram(unittest.TestCase):
    def test_mutation_returns_valid_program(self):
        base = sb.rand_program(8)
        for _ in range(30):
            child = sb.mutate_program(base)
            sb.validate_program(child)

    def test_does_not_mutate_original(self):
        base = sb.rand_program(8)
        original_str = sb.program_to_str(base)
        for _ in range(20):
            sb.mutate_program(base)
        self.assertEqual(sb.program_to_str(base), original_str)

    def test_child_has_distinct_id_and_lineage(self):
        base = sb.rand_program(8)
        child = sb.mutate_program(base)
        self.assertNotEqual(child.id, base.id)
        self.assertIn(base.id, child.lineage)


class TestCrossoverProgram(unittest.TestCase):
    def test_crossover_returns_valid_program(self):
        a = sb.rand_program(8)
        b = sb.rand_program(8)
        for _ in range(30):
            child = sb.crossover_program(a, b)
            sb.validate_program(child)

    def test_parents_unaffected(self):
        a = sb.rand_program(8)
        b = sb.rand_program(8)
        a_str, b_str = sb.program_to_str(a), sb.program_to_str(b)
        for _ in range(20):
            sb.crossover_program(a, b)
        self.assertEqual(sb.program_to_str(a), a_str)
        self.assertEqual(sb.program_to_str(b), b_str)

    def test_fallback_on_empty_parent(self):
        empty_ok_parent = sb.Program(sb.Block([sb.AssignStmt("x", sb.ConstExpr(1.0))]))
        other = sb.rand_program(8)
        child = sb.crossover_program(empty_ok_parent, other)
        sb.validate_program(child)


class TestCloneProgram(unittest.TestCase):
    def test_deep_independence(self):
        prog = sb.rand_program(8)
        clone = sb.clone_program(prog)
        # mutate the clone's AST in place and verify the original is untouched
        first_stmt = clone.body.statements[0]
        if isinstance(first_stmt, sb.AssignStmt):
            first_stmt.target = "z"
        clone.body.statements.append(sb.AssignStmt("x", sb.ConstExpr(9.0)))
        self.assertNotEqual(len(prog.body.statements), len(clone.body.statements))

    def test_clone_has_new_id(self):
        prog = sb.rand_program(4)
        clone = sb.clone_program(prog)
        self.assertNotEqual(prog.id, clone.id)

    def test_clone_is_valid(self):
        prog = sb.rand_program(6)
        clone = sb.clone_program(prog)
        sb.validate_program(clone)


class TestSerialization(unittest.TestCase):
    def test_stmt_to_str_all_types(self):
        exprs_stmts = [
            sb.AssignStmt("x", sb.ConstExpr(1.0)),
            sb.TickStmt(sb.ConstExpr(2)),
            sb.OutputStmt(sb.VarExpr("x")),
            sb.MemWriteStmt("k1", sb.ConstExpr(1.0)),
            sb.EmitStmt(sb.ConstExpr(1.0), 0, 0),
            sb.CoupleStmt(0, 1),
            sb.IfStmt(sb.ConstExpr(1.0), sb.Block([]), sb.Block([])),
        ]
        for s in exprs_stmts:
            text = sb.stmt_to_str(s)
            self.assertIsInstance(text, str)
            self.assertNotIn("0x", text)  # no raw object addresses

    def test_flatten_recurses_into_branches(self):
        prog = sb.Program(sb.Block([
            sb.IfStmt(
                sb.ConstExpr(1.0),
                sb.Block([sb.AssignStmt("x", sb.ConstExpr(1.0))]),
                sb.Block([sb.OutputStmt(sb.ConstExpr(2.0))]),
            )
        ]))
        flat = sb.flatten_statement_strings(prog)
        self.assertEqual(len(flat), 3)  # if, then-assign, else-output

    def test_program_to_str_is_indented(self):
        prog = sb.Program(sb.Block([
            sb.IfStmt(
                sb.ConstExpr(1.0),
                sb.Block([sb.AssignStmt("x", sb.ConstExpr(1.0))]),
                sb.Block([sb.OutputStmt(sb.ConstExpr(2.0))]),
            )
        ]))
        text = sb.program_to_str(prog)
        self.assertIn("    x = 1", text)


class TestExecution(unittest.TestCase):
    def test_program_runs_successfully(self):
        prog = sb.rand_program(8)
        rt = fresh_rt()
        result = prog.run(rt)
        self.assertTrue(result["success"])

    def test_scoring_produces_metrics(self):
        prog = sb.rand_program(8)
        rt = fresh_rt()
        result = prog.run(rt)
        rt.tick_states()
        metrics = sb.score_runtime(prog, rt, result)
        self.assertIn("fitness", metrics)
        self.assertIsInstance(metrics["fitness"], float)

    def score(self, program, expected="1.0"):
        task = sb.CoordinationTask(expected_outputs=[expected], input_values={})
        rt = sb.Runtime(num_channels=sb.NUM_CHANNELS, num_domains=sb.NUM_DOMAINS, task_spec=task)
        result = program.run(rt)
        return sb.score_runtime(program, rt, result)

    def test_missing_memory_read_has_no_reward(self):
        metrics = self.score(sb.Program(sb.Block([sb.OutputStmt(sb.MemoryReadExpr("missing"))])), "0.0")
        self.assertEqual(metrics["R_mem_useful"], 0.0)
        self.assertGreater(metrics["invalid_memory_reads"], 0)
        sb.assert_metric_invariants(metrics)

    def test_irrelevant_memory_has_no_reward(self):
        program = sb.Program(sb.Block([
            sb.MemWriteStmt("k1", sb.ConstExpr(7.0)),
            sb.AssignStmt("x", sb.MemoryReadExpr("k1")),
            sb.OutputStmt(sb.ConstExpr(1.0)),
        ]))
        metrics = self.score(program)
        self.assertEqual(metrics["R_mem_useful"], 0.0)

    def test_useful_memory_requires_write_read_and_success(self):
        program = sb.Program(sb.Block([
            sb.MemWriteStmt("k1", sb.ConstExpr(7.0)),
            sb.OutputStmt(sb.MemoryReadExpr("k1")),
        ]))
        metrics = self.score(program, "7.0")
        self.assertGreater(metrics["R_mem_useful"], 0.0)
        self.assertGreater(metrics["memory_causal_contributions"], 0)
        sb.assert_metric_invariants(metrics)

    def test_state_spam_is_not_productive(self):
        program = sb.Program(sb.Block([
            sb.EmitStmt(sb.ConstExpr(1.0), 0, 0),
            sb.EmitStmt(sb.ConstExpr(1.0), 0, 1),
            sb.EmitStmt(sb.ConstExpr(1.0), 0, 2),
        ]))
        metrics = self.score(program)
        self.assertEqual(metrics["R_state_prod"], 0.0)

    def test_attractor_farming_is_not_useful(self):
        program = sb.Program(sb.Block([
            sb.EmitStmt(sb.ConstExpr(1.0), 0, 0),
            sb.TickStmt(sb.ConstExpr(2.0)),
        ]))
        metrics = self.score(program)
        self.assertEqual(metrics["R_attractor_useful"], 0.0)

    def test_output_spam_has_no_scoring_advantage(self):
        program = sb.Program(sb.Block([
            sb.OutputStmt(sb.ConstExpr(1.0)),
            sb.OutputStmt(sb.ConstExpr(1.0)),
            sb.OutputStmt(sb.ConstExpr(1.0)),
        ]))
        metrics = self.score(program)
        self.assertGreater(metrics["P_repeated_output"], 0.0)

    def test_repeated_blocks_are_penalized(self):
        stmt = sb.OutputStmt(sb.ConstExpr(1.0))
        program = sb.Program(sb.Block([stmt.clone(), stmt.clone(), stmt.clone()]))
        metrics = self.score(program)
        self.assertGreater(metrics["P_block_rep"], 0.0)


class TestEvolutionEngine(unittest.TestCase):
    def test_one_generation(self):
        random.seed(7)
        engine = sb.MorphoFieldEvolutionEngine(pop_size=6, program_len=5)
        best, records, batch_ms = engine.step()
        self.assertEqual(len(records), 6)
        self.assertIn("fitness", best.metrics)
        for p in engine.population:
            sb.validate_program(p)

    def test_task_splits_are_deterministic_and_disjoint(self):
        first = sb.make_task_splits(seed=12, size=4)
        second = sb.make_task_splits(seed=12, size=4)
        self.assertEqual(
            [t.expected_outputs for t in first.training],
            [t.expected_outputs for t in second.training],
        )
        self.assertTrue(set(id(t) for t in first.training).isdisjoint(id(t) for t in first.held_out))

    def test_procedural_tasks_have_distinct_family_semantics(self):
        splits = sb.make_task_splits(seed=4, size=7)
        tasks = splits.training
        self.assertEqual({task.family for task in tasks}, {
            "memory", "causal", "attractor", "conditional", "delayed", "cross_domain", "negative_control"
        })
        self.assertGreater(len({task.expected_outputs[0] for task in tasks}), 1)
        memory_task = next(task for task in tasks if task.family == "memory")
        self.assertNotEqual(memory_task.expected_outputs[0], str(memory_task.input_values["x"]))
        self.assertTrue(memory_task.require_memory_use)
        self.assertTrue(next(task for task in tasks if task.family == "causal").require_state_productivity)

    def test_constant_output_cannot_solve_all_task_families(self):
        splits = sb.make_task_splits(seed=8, size=7)
        program = sb.Program(sb.Block([sb.OutputStmt(sb.ConstExpr(0.0))]))
        accuracies = [
            sb.MorphoFieldEvolutionEngine(pop_size=1).evaluate_program_on_task(program, task).metrics["task_completion"]
            for task in splits.training
        ]
        self.assertLess(sum(accuracies), len(accuracies))

    def test_shortcut_on_memory_target_fails_without_memory_causality(self):
        task = next(task for task in sb.make_task_splits(seed=3, size=7).training if task.family == "memory")
        target = float(task.expected_outputs[0])
        program = sb.Program(sb.Block([sb.OutputStmt(sb.ConstExpr(target))]))
        record = sb.MorphoFieldEvolutionEngine(pop_size=1).evaluate_program_on_task(program, task)
        self.assertEqual(record.metrics["task_completion"], 0.0)
        self.assertEqual(record.metrics["valid_memory_reads"], 0)

    def test_intervention_report_is_bounded(self):
        program = sb.Program(sb.Block([sb.OutputStmt(sb.ConstExpr(1.0))]))
        task = sb.CoordinationTask(expected_outputs=["1.0"])
        report = sb.verify_causal_interventions(program, task)
        self.assertEqual(report["baseline"], 1.0)
        for component in ("memory", "attractor", "state", "coupling"):
            self.assertGreaterEqual(report[f"without_{component}"], 0.0)
            self.assertLessEqual(report[f"without_{component}"], 1.0)


class TestIntegrationEvolution(unittest.TestCase):
    def test_multi_generation_run(self):
        random.seed(99)
        engine = sb.MorphoFieldEvolutionEngine(pop_size=8, program_len=6)
        fitness_progression = []
        for _ in range(4):
            best, records, batch_ms = engine.step()
            fitness_progression.append(best.metrics["fitness"])
            self.assertTrue(all("fitness" in r.metrics for r in records))
            for p in engine.population:
                sb.validate_program(p)
        self.assertEqual(engine.generation, 4)
        self.assertEqual(len(fitness_progression), 4)


if __name__ == "__main__":
    unittest.main()
